<?php
/**
 * Weekly timesheet grid and multi-level approval.
 *
 * Employees submit their own week. Managers/admins review the queue, approve
 * or reject with a note, and every decision is audited and notified.
 */

declare(strict_types=1);

final class TimesheetController extends Controller
{
    private Timesheet $timesheets;

    public function __construct()
    {
        parent::__construct(true);
        $this->timesheets = new Timesheet();
    }

    /** GET /timesheets */
    public function myTimesheet(Request $request, array $params): void
    {
        PermissionHelper::require('time.view_own');
        $this->requireInstalled();

        $userId = (int) AuthHelper::id();
        $week   = $this->parseWeek((string) $request->input('week', ''));
        $matrix = $this->timesheets->getWeeklyMatrix($userId, $week->format('Y-m-d'));

        $timesheet = $matrix['timesheet'];
        $status    = (string) (($timesheet['status'] ?? '') ?: Timesheet::STATUS_DRAFT);
        $locked    = in_array($status, [Timesheet::STATUS_SUBMITTED, Timesheet::STATUS_APPROVED], true);
        $canSubmit = PermissionHelper::has('time.edit_own')
            && !$locked
            && $matrix['entry_count'] > 0;

        $this->view('timesheets/my_timesheet', [
            'pageTitle'  => 'Timesheet',
            'activeTab'  => 'mine',
            'weekStart'  => $week,
            'prevWeek'   => $week->modify('-7 days')->format('Y-m-d'),
            'nextWeek'   => $week->modify('+7 days')->format('Y-m-d'),
            'thisWeek'   => $this->currentMonday()->format('Y-m-d'),
            'matrix'     => $matrix,
            'timesheet'  => $timesheet,
            'status'     => $status,
            'locked'     => $locked,
            'canSubmit'  => $canSubmit,
            'canApprove' => PermissionHelper::has('time.approve'),
            'view'       => 'week',
        ]);
    }

    /** GET /timesheets/month */
    public function myMonth(Request $request, array $params): void
    {
        PermissionHelper::require('time.view_own');
        $this->requireInstalled();

        $userId = (int) AuthHelper::id();
        $month  = $this->parseMonth((string) $request->input('month', ''));
        $overview = $this->timesheets->getMonthlyOverview($userId, $month->format('Y-m-d'));

        $this->view('timesheets/my_timesheet', [
            'pageTitle'  => 'Timesheet',
            'activeTab'  => 'mine',
            'weekStart'  => $this->currentMonday(),
            'prevWeek'   => $month->modify('-1 month')->format('Y-m-01'),
            'nextWeek'   => $month->modify('+1 month')->format('Y-m-01'),
            'thisWeek'   => (new DateTimeImmutable('first day of this month', $month->getTimezone()))->format('Y-m-d'),
            'matrix'     => null,
            'month'      => $overview,
            'timesheet'  => null,
            'status'     => Timesheet::STATUS_DRAFT,
            'locked'     => false,
            'canSubmit'  => false,
            'canApprove' => PermissionHelper::has('time.approve'),
            'view'       => 'month',
        ]);
    }

    /** POST /timesheets/submit */
    public function submit(Request $request, array $params): void
    {
        PermissionHelper::require('time.edit_own');
        $this->requireInstalled($request->wantsJson());

        $week = $this->parseWeek((string) $request->input('week', ''));
        $path = '/timesheets?week=' . $week->format('Y-m-d');

        try {
            $timesheet = $this->timesheets->submitWeek((int) AuthHelper::id(), $week->format('Y-m-d'));
        } catch (RuntimeException $e) {
            $this->failAction($e->getMessage(), $path, 409);
        }

        LoggerHelper::audit('timesheet.submitted', 'timesheet', (int) $timesheet['id'], [
            'start_date'       => (string) $timesheet['start_date'],
            'end_date'         => (string) $timesheet['end_date'],
            'total_seconds'    => (int) $timesheet['total_seconds'],
            'billable_seconds' => (int) $timesheet['billable_seconds'],
        ]);

        $label = FormatHelper::date((string) $timesheet['start_date'] . ' 00:00:00', 'M j')
            . ' – '
            . FormatHelper::date((string) $timesheet['end_date'] . ' 00:00:00', 'M j, Y');

        foreach ($this->timesheets->approverIdsFor($timesheet, (int) AuthHelper::id()) as $approverId) {
            $this->timesheets->notify(
                $approverId,
                'info',
                'Timesheet submitted',
                (string) AuthHelper::user()['name'] . ' submitted a timesheet for ' . $label . '.',
                '/timesheets/' . (int) $timesheet['id']
            );
        }

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true, 'timesheet_id' => (int) $timesheet['id']]);
        }

        $this->flash('success', 'Timesheet for ' . $label . ' was submitted for approval.');
        $this->redirect($path);
    }

    /** GET /timesheets/team */
    public function teamTimesheets(Request $request, array $params): void
    {
        PermissionHelper::require('time.approve');
        $this->requireInstalled();

        $status = (string) $request->input('status', Timesheet::STATUS_SUBMITTED);
        if ($status !== 'all' && !in_array($status, Timesheet::STATUSES, true)) {
            $status = Timesheet::STATUS_SUBMITTED;
        }

        $filters = [
            'status'  => $status,
            'user_id' => (int) $request->input('user_id', 0),
            'q'       => trim((string) $request->input('q', '')),
        ];

        $userId  = (int) AuthHelper::id();
        $isAdmin = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);
        $result  = $this->timesheets->queueForApprover(
            $userId,
            $isAdmin,
            $filters,
            (int) $request->input('page', 1),
            25
        );

        $people = Database::fetchAll(
            "SELECT id, name FROM users
             WHERE status = 'active' AND role IN ('employee','manager','admin') AND id <> :id
             ORDER BY name ASC",
            ['id' => $userId]
        );

        $this->view('timesheets/team_approval', [
            'pageTitle'  => 'Timesheet approval',
            'activeTab'  => 'team',
            'result'     => $result,
            'filters'    => $filters,
            'people'     => $people,
            'counts'     => $result['counts'],
            'canApprove' => true,
        ]);
    }

    /** GET /timesheets/{id} */
    public function show(Request $request, array $params): void
    {
        PermissionHelper::require('time.view_own');
        $this->requireInstalled();

        $id        = (int) ($params['id'] ?? 0);
        $timesheet = $this->timesheets->findWithRelations($id);
        if ($timesheet === null) {
            $this->notFound();
        }

        $userId     = (int) AuthHelper::id();
        $isAdmin    = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);
        $canApprove = PermissionHelper::has('time.approve');

        if (!$this->timesheets->userCanView($timesheet, $userId, $isAdmin, $canApprove)) {
            $this->forbidden();
        }

        $matrix  = $this->timesheets->getWeeklyMatrix((int) $timesheet['user_id'], (string) $timesheet['start_date']);
        $entries = $this->timesheets->entriesFor($id);
        $canDecide = $this->timesheets->userCanDecide($timesheet, $userId, $isAdmin, $canApprove)
            && (string) $timesheet['status'] === Timesheet::STATUS_SUBMITTED;

        $this->view('timesheets/view', [
            'pageTitle'  => 'Timesheet',
            'timesheet'  => $timesheet,
            'matrix'     => $matrix,
            'entries'    => $entries,
            'canDecide'  => $canDecide,
            'isOwn'      => (int) $timesheet['user_id'] === $userId,
        ]);
    }

    /** POST /timesheets/{id}/approve */
    public function approveAction(Request $request, array $params): void
    {
        PermissionHelper::require('time.approve');
        $this->requireInstalled($request->wantsJson());

        $id        = (int) ($params['id'] ?? 0);
        $timesheet = $this->assertDecidable($id);
        $path      = '/timesheets/' . $id;

        try {
            $updated = $this->timesheets->approve($id, (int) AuthHelper::id());
        } catch (RuntimeException $e) {
            $this->failAction($e->getMessage(), $path, 409);
        }

        LoggerHelper::audit('timesheet.approved', 'timesheet', $id, [
            'user_id'          => (int) $updated['user_id'],
            'start_date'       => (string) $updated['start_date'],
            'total_seconds'    => (int) $updated['total_seconds'],
            'billable_seconds' => (int) $updated['billable_seconds'],
        ]);

        $label = $this->periodLabel($updated);
        $this->timesheets->notify(
            (int) $updated['user_id'],
            'success',
            'Timesheet approved',
            'Your timesheet for ' . $label . ' was approved.',
            '/timesheets/' . $id
        );

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true, 'status' => Timesheet::STATUS_APPROVED]);
        }

        $this->flash('success', 'Timesheet for ' . (string) $updated['user_name'] . ' (' . $label . ') was approved.');
        $this->redirect($this->backPath('/timesheets/team'));
    }

    /** POST /timesheets/{id}/reject */
    public function rejectAction(Request $request, array $params): void
    {
        PermissionHelper::require('time.approve');
        $this->requireInstalled($request->wantsJson());

        $id        = (int) ($params['id'] ?? 0);
        $timesheet = $this->assertDecidable($id);
        $path      = '/timesheets/' . $id;

        $reason = trim((string) $request->input('reason', $request->input('rejection_reason', '')));
        if ($reason === '') {
            $this->failAction('A rejection reason is required.', $path, 422);
        }

        try {
            $updated = $this->timesheets->reject($id, (int) AuthHelper::id(), $reason);
        } catch (InvalidArgumentException $e) {
            $this->failAction($e->getMessage(), $path, 422);
        } catch (RuntimeException $e) {
            $this->failAction($e->getMessage(), $path, 409);
        }

        LoggerHelper::audit('timesheet.rejected', 'timesheet', $id, [
            'user_id'    => (int) $updated['user_id'],
            'start_date' => (string) $updated['start_date'],
            'reason'     => mb_substr($reason, 0, 200, 'UTF-8'),
        ]);

        $label = $this->periodLabel($updated);
        $this->timesheets->notify(
            (int) $updated['user_id'],
            'warning',
            'Timesheet needs changes',
            'Your timesheet for ' . $label . ' was rejected. ' . $reason,
            '/timesheets/' . $id
        );

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true, 'status' => Timesheet::STATUS_REJECTED]);
        }

        $this->flash('warning', 'Timesheet for ' . (string) $updated['user_name'] . ' was rejected.');
        $this->redirect($this->backPath('/timesheets/team'));
    }

    /** POST /timesheets/batch-approve */
    public function batchApprove(Request $request, array $params): void
    {
        PermissionHelper::require('time.approve');
        $this->requireInstalled($request->wantsJson());

        $ids = $this->idList($request->input('ids', []));
        if ($ids === []) {
            $this->failAction('Select at least one timesheet.', '/timesheets/team', 422);
        }

        $approved = 0;
        $skipped  = 0;
        $approverId = (int) AuthHelper::id();

        foreach ($ids as $id) {
            try {
                $this->assertDecidable($id);
                $updated = $this->timesheets->approve($id, $approverId);
            } catch (Throwable $e) {
                $skipped++;
                continue;
            }

            LoggerHelper::audit('timesheet.approved', 'timesheet', $id, [
                'user_id'    => (int) $updated['user_id'],
                'start_date' => (string) $updated['start_date'],
                'batch'      => true,
            ]);

            $this->timesheets->notify(
                (int) $updated['user_id'],
                'success',
                'Timesheet approved',
                'Your timesheet for ' . $this->periodLabel($updated) . ' was approved.',
                '/timesheets/' . $id
            );
            $approved++;
        }

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true, 'approved' => $approved, 'skipped' => $skipped]);
        }

        if ($approved > 0) {
            $this->flash('success', $approved . ' timesheet' . ($approved === 1 ? '' : 's') . ' approved.');
        }
        if ($skipped > 0) {
            $this->flash('warning', $skipped . ' timesheet' . ($skipped === 1 ? '' : 's') . ' could not be approved.');
        }
        $this->redirect('/timesheets/team');
    }

    private function requireInstalled(bool $asJson = false): void
    {
        if (Timesheet::installed() && TimeEntry::installed()) {
            return;
        }

        if ($asJson || $this->request->wantsJson()) {
            $this->json(['ok' => false, 'error' => ['status' => 503, 'message' => 'Timesheets are not installed yet.']], 503);
        }

        $this->flash('warning', 'Timesheet tables are not installed. Import database/phase7.sql.');
        $this->redirect('/dashboard');
    }

    /** @return array<string, mixed> */
    private function assertDecidable(int $id): array
    {
        $timesheet = $this->timesheets->findWithRelations($id);
        if ($timesheet === null) {
            $this->notFound();
        }

        $userId  = (int) AuthHelper::id();
        $isAdmin = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);

        if (!$this->timesheets->userCanDecide($timesheet, $userId, $isAdmin, true)) {
            $this->forbidden();
        }

        return $timesheet;
    }

    private function parseWeek(string $value): DateTimeImmutable
    {
        $zone = new DateTimeZone(FormatHelper::displayTimezone());
        if ($value !== '') {
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $value, $zone);
            $errors = DateTimeImmutable::getLastErrors();
            if ($parsed !== false && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
                return $parsed->modify('Monday this week')->setTime(0, 0, 0);
            }
        }

        return $this->currentMonday();
    }

    private function parseMonth(string $value): DateTimeImmutable
    {
        $zone = new DateTimeZone(FormatHelper::displayTimezone());
        if ($value !== '' && preg_match('/^\d{4}-\d{2}(-\d{2})?$/', $value) === 1) {
            $normalized = strlen($value) === 7 ? $value . '-01' : $value;
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $normalized, $zone);
            $errors = DateTimeImmutable::getLastErrors();
            if ($parsed !== false && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
                return $parsed->modify('first day of this month')->setTime(0, 0, 0);
            }
        }

        return (new DateTimeImmutable('first day of this month', $zone))->setTime(0, 0, 0);
    }

    private function currentMonday(): DateTimeImmutable
    {
        $zone = new DateTimeZone(FormatHelper::displayTimezone());

        return (new DateTimeImmutable('today', $zone))->modify('Monday this week')->setTime(0, 0, 0);
    }

    /** @param array<string, mixed> $timesheet */
    private function periodLabel(array $timesheet): string
    {
        $start = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $timesheet['start_date']);
        $end   = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $timesheet['end_date']);
        if ($start === false || $end === false) {
            return (string) $timesheet['start_date'] . ' – ' . (string) $timesheet['end_date'];
        }

        return $start->format('M j') . ' – ' . $end->format('M j, Y');
    }

    /**
     * @param mixed $raw
     * @return list<int>
     */
    private function idList(mixed $raw): array
    {
        if (is_string($raw) && $raw !== '') {
            $raw = explode(',', $raw);
        }
        if (!is_array($raw)) {
            return [];
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = (int) $value;
            if ($id > 0) {
                $ids[$id] = true;
            }
        }

        return array_map('intval', array_keys($ids));
    }

    private function backPath(string $fallback): string
    {
        $referer = (string) ($this->request->header('referer') ?? '');
        if ($referer === '') {
            return $fallback;
        }

        $path = parse_url($referer, PHP_URL_PATH);
        if (!is_string($path) || $path === '') {
            return $fallback;
        }

        $base = Request::basePath();
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = substr($path, strlen($base)) ?: '/';
        }

        if (str_starts_with($path, '/timesheets')) {
            $query = parse_url($referer, PHP_URL_QUERY);
            return is_string($query) && $query !== '' ? $path . '?' . $query : $path;
        }

        return $fallback;
    }

    private function failAction(string $message, string $path, int $status): never
    {
        if ($this->request->wantsJson() || $this->request->isAjax()) {
            $this->json(['ok' => false, 'error' => ['status' => $status, 'message' => $message]], $status);
        }

        $this->flash($status >= 500 ? 'danger' : 'warning', $message);
        $this->redirect($path);
    }
}
